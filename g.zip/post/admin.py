from django.contrib import admin

from .models import LostPet

admin.site.register(LostPet)